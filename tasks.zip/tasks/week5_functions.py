def square(x):
    return x ** 2


def add(x, y):
    while y > 0:
        x += 1
        y -= 1
    return x

print add(3, 2)


def get_0():
    return 0

defrosted = False
#def f(x):
"def g(y):"
